# todo/views.py

from django.shortcuts import get_object_or_404
from django.views import generic

class IndexView(generic.ListView):
    template_name = 'index.html'
context_object_name='todo'
def get_queryset(self):
        return Todo.objects.all()