
from django.shortcuts import render, get_object_or_404, redirect
from .models import Todo



class IndexView:
    pass

def add(request):
    pass

def delete(request,todo_id):
    pass

def update(request,todo_id):
    pass
