# todo/views.py


from django.shortcuts import *

  def delete(request,id):
todo=get_object_or_404(Todo,id=id)
  todo.delete()
return redirect('/')