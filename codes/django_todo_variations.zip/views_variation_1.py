# todo/views.py

from django.shortcuts import render

  def add(request):
  title=request.POST.get('title')
Todo.objects.create(title=title)
    return redirect('/')